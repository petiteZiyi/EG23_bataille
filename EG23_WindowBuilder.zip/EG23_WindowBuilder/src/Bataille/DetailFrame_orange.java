package Bataille;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class DetailFrame_orange extends JFrame{

	private JFrame frame;
	
	MeleeFrameback2 meleeframeback2=new MeleeFrameback2();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DetailFrame_orange window = new DetailFrame_orange();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public DetailFrame_orange() {
		meleeframeback2.setVisible(false);
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Detail Frame");
        setBounds(100, 100, 1400, 1000);
        getContentPane().setLayout(null);
        
        JButton ReturnButton = new JButton("");
        ReturnButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		meleeframeback2.setVisible(true);
        		setVisible(false);
        	}
        });
        // Définition de l'icône du bouton à partir des ressources
        ReturnButton.setIcon(new ImageIcon(DetailFrame_green.class.getResource("/imgs/return.png")));
        ReturnButton.setBounds(1259, 864, 142, 97);
        getContentPane().add(ReturnButton);
        ReturnButton.setBorderPainted(false);
        
        // Création d'une étiquette "BackgroundLabel" sans texte
        JLabel BackgroundLabel = new JLabel("");
        BackgroundLabel.setIcon(new ImageIcon(DetailFrame_orange.class.getResource("/imgs/background7.png")));
        BackgroundLabel.setBounds(0, -15, 1400, 1000);
        getContentPane().add(BackgroundLabel);
	}

}
