package Bataille;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class StartFrame extends JFrame{

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StartFrame window = new StartFrame();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public StartFrame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Start Frame");
        setBounds(100, 100, 1400, 1000);
        getContentPane().setLayout(null);
        
        JButton btnNewButton = new JButton("");
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		System.exit(0);
        	}
        });
        btnNewButton.setIcon(new ImageIcon(StartFrame.class.getResource("/imgs/exit_icon.png")));
        btnNewButton.setBounds(130, 667, 151, 72);
        getContentPane().add(btnNewButton);
        btnNewButton.setBorderPainted(false);
        
        JLabel BackgroundLabel = new JLabel("");
        BackgroundLabel.setIcon(new ImageIcon(StartFrame.class.getResource("/imgs/background0.png")));
        BackgroundLabel.setBounds(0, -14, 1400, 1000);
        getContentPane().add(BackgroundLabel);
        
	}

}
