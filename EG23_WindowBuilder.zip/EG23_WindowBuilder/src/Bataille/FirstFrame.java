package Bataille;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.net.URL;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class FirstFrame {
	
	PlayFrame playframe = new PlayFrame();
	
	
	private JFrame frame;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FirstFrame window = new FirstFrame();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FirstFrame() {
		playframe.setVisible(false);
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		JButton RulesButton = new JButton("");
		RulesButton.setIcon(new ImageIcon(FirstFrame.class.getResource("/imgs/rules_icon.png")));
		JList<String> RulesList = new JList<String>();
		JScrollPane scrollPane = new JScrollPane();
		
		frame.setBounds(100, 100, 1400, 1000);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		JButton PlayButton = new JButton("");
		
		JButton ExitButton = new JButton("");
		ExitButton.setIcon(new ImageIcon(FirstFrame.class.getResource("/imgs/exit_icon.png")));
		JButton SettingButton = new JButton("");
		SettingButton.setIcon(new ImageIcon(FirstFrame.class.getResource("/imgs/setting_icon.png")));
		JLabel ReturnLabel = new JLabel("");
		
		
		//PlayButton:
		PlayButton.setBounds(130, 400, 156, 80);
		frame.getContentPane().add(PlayButton);
		PlayButton.setBorderPainted(false);
		PlayButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			    playframe.setVisible(true);             // 显示第二个 JFrame
			    frame.setVisible(false);
			}
		});
		PlayButton.setSelectedIcon(new ImageIcon(FirstFrame.class.getResource("/imgs/play_icon.png")));
		PlayButton.setIcon(new ImageIcon(FirstFrame.class.getResource("/imgs/play_icon.png")));
		
		
		//ExitButton
		ExitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0); 
			}
		});
		ExitButton.setBounds(140, 665, 147, 68);
		ExitButton.setBorderPainted(false);
		frame.getContentPane().add(ExitButton);
		
		
		//SettingButton
		SettingButton.setBounds(90, 490, 253, 80);
		SettingButton.setBorderPainted(false);
		frame.getContentPane().add(SettingButton);
		
		
		
		//ReturnLabel
		ReturnLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				PlayButton.setVisible(true);
				SettingButton.setVisible(true);
				RulesButton.setVisible(true);
				ExitButton.setVisible(true);
				ReturnLabel.setVisible(false);
				RulesList.setVisible(false);
				scrollPane.setVisible(false);
			}
		});
		ReturnLabel.setIcon(new ImageIcon(FirstFrame.class.getResource("/imgs/return.png")));
		ReturnLabel.setBounds(0, 855, 132, 106);
		frame.getContentPane().add(ReturnLabel);
		ReturnLabel.setVisible(false);
		
		
		
		
		
		//RulesButton  rule在同一个界面上，把规则框和返回设为可见
		RulesButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PlayButton.setVisible(false);
				SettingButton.setVisible(false);
				RulesButton.setVisible(false);
				ExitButton.setVisible(false);
				ReturnLabel.setVisible(true);
				RulesList.setVisible(true);
				scrollPane.setVisible(true);
			}
		});
		RulesButton.setBounds(110, 580, 209, 68);
		frame.getContentPane().add(RulesButton);
		RulesButton.setBorderPainted(false);
		
		
		
		
		//JScrollPane,用于承载list，并new一个list
		scrollPane.setBounds(90, 300, 789, 512);
		frame.getContentPane().add(scrollPane);
		
		RulesList.setBorder(null);
		RulesList.setForeground(Color.GRAY);
		RulesList.setBackground(new Color(255, 255, 204));
		scrollPane.setViewportView(RulesList);
		scrollPane.setVisible(false);
		
		//RulesList
		RulesList.setFont(new Font("Agency FB", Font.PLAIN, 25));
		RulesList.setModel(new AbstractListModel() {
			String[] values = new String[] {"Règles du Jeu : La Bataille des Programmes", "", "------------Introduction------------", "    \"La Bataille des Programmes\" est un jeu stratégique à deux joueurs, se déroulant à l'Université ", "de Technologie de Troyes. Chaque joueur représente un des 7 programmes de l'UTT et commande ", "une armée de 20 combattants.", "", "------------Objectif du Jeu-------------", "Contrôler la majorité des zones d'influence de l'Université pour remporter la victoire. ", "Les zones d'influence sont :", "    ·  La bibliothèque", "    · Le Bureau des Étudiants", "    · Le Quartier Administratif", "    · Les Halles industrielles", "    · La Halle Sportive", "", "----------Déroulement du Jeu-----------", "1. Paramétrage des Troupes :", "    · Chaque joueur dispose de 400 points à distribuer entre les caractéristiques ", "      de ses 20 combattants.", "    · Chaque joueur sélectionne 5 combattants comme réservistes.", "    · Chaque combattant se voit attribuer une IA : Défensif, Offensif ou Aléatoire.", "", "2. Affectation des Troupes sur les Champs de Batailles :", "    · Les joueurs répartissent leurs 15 combattants actifs sur les 5 zones de combat.", "    · Au moins 1 combattant doit être assigné à chaque zone.", "", "3. Première Mêlée :", "    · Les combats débutent dans les 5 zones.", "    · Les points de vie des combattants évoluent selon les attaques et soins reçus.", "    · La mêlée se termine lorsqu'une zone est contrôlée par un joueur. Une trêve est alors déclarée.", "", "4. Trêve et Mouvements de Troupes :", "    · Les joueurs peuvent déployer des réservistes sur les zones non contrôlées.", "    · Les joueurs peuvent redéployer des combattants valides depuis une zone contrôlée", "      vers d'autres zones, tout en maintenant un combattant sur la zone contrôlée.", "    · Les combattants redéployés conservent leurs points de vie actuels.", "", "5.Cycle Mêlées – Trêves :", "    · Les étapes de mêlée et de trêve se répètent jusqu'à ce qu'un joueur contrôle au ", "      moins 3 zones, le déclarant ainsi vainqueur.", "", "6.Conditions de Victoire :", "    · Le premier joueur à contrôler 3 zones d'influence remporte la partie.", "", "    Ce jeu demande une stratégie réfléchie pour l'allocation des points, la répartition des ", "combattants et l'utilisation judicieuse des réservistes pour prendre l'avantage sur l'adversaire."};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		RulesList.setVisible(false);
		
		
		
		
		
		
		//BackgroundLabel:
		JLabel BackgroundLabel = new JLabel(""); BackgroundLabel.setIcon(new ImageIcon(FirstFrame.class.getResource("/imgs/background0.png")));
		BackgroundLabel.setBounds(0, -11, 1425, 1000);
		frame.getContentPane().add(BackgroundLabel);
		
		
		 
	}
	
	//关闭playframe的方法
		public void close_palyframe() {
			playframe.setVisible(false);
		}
}
