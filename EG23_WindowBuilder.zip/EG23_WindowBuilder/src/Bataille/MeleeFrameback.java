package Bataille;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class MeleeFrameback extends JFrame {
	
	private JFrame frame;
	
	DetailFrame_orange detailframe_orange = new DetailFrame_orange();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MeleeFrameback window = new MeleeFrameback();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MeleeFrameback() {
		detailframe_orange.setVisible(false);
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Melée Frame");
        setBounds(100, 100, 1400, 1000);
        getContentPane().setLayout(null);
        
        //button pour return
        JButton btnNewButton = new JButton("");
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		detailframe_orange.setVisible(true);
        		setVisible(false);
        	}
        });
        btnNewButton.setIcon(new ImageIcon(MeleeFrameback.class.getResource("/imgs/DetailOrange.png")));
        btnNewButton.setBounds(783, 237, 180, 97);
        getContentPane().add(btnNewButton);
        
        JLabel GuideText1 = new JLabel("La barre rouge représente les points de vies de l'ennemi.");
        GuideText1.setForeground(new Color(128, 0, 0));
        GuideText1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
        GuideText1.setBounds(42, 892, 742, 40);
        getContentPane().add(GuideText1);
        
        JLabel GuideText2 = new JLabel("La barre bleue représente vos propres points de vies.");
        GuideText2.setForeground(new Color(128, 0, 0));
        GuideText2.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
        GuideText2.setBounds(730, 892, 742, 40);
        getContentPane().add(GuideText2);
        
        JLabel GuideText3 = new JLabel("Cliquez sur une barre pour connaître l'état exact de la bataille dans la zone.");
        GuideText3.setForeground(new Color(128, 0, 0));
        GuideText3.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 35));
        GuideText3.setBounds(277, 38, 1097, 40);
        getContentPane().add(GuideText3);
        
        //background
        JLabel BackgroundLabel1 = new JLabel("");
        BackgroundLabel1.setIcon(new ImageIcon(MeleeFrame.class.getResource("/imgs/background4.png")));
        BackgroundLabel1.setBounds(0, -14, 1400, 1000);
        getContentPane().add(BackgroundLabel1);
        
        
        
        
	}
}