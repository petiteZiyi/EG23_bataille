package Bataille;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.SystemColor;

public class TreveFrame extends JFrame{

	private JFrame frame;
	FinalFrame finalframe=new FinalFrame();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TreveFrame window = new TreveFrame();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TreveFrame() {
		finalframe.setVisible(false);
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Trêve Frame");
        setBounds(100, 100, 1400, 1000);
        getContentPane().setLayout(null);
        
        //一些实例化语句
        JButton DeleteButton2 = new JButton("");
        JButton Soldat6Button = new JButton("");
        JButton Soldat9Button = new JButton("");
        JButton Soldat11Button = new JButton("");
        
        JLabel NumberLable1 = new JLabel("2");
	    NumberLable1.setForeground(new Color(255, 255, 204));
	    NumberLable1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 35));
	    NumberLable1.setBounds(354, 253, 24, 45);
	    getContentPane().add(NumberLable1);
	    
	    JLabel NumberLable2 = new JLabel("1");
	    NumberLable2.setForeground(new Color(255, 255, 204));
	    NumberLable2.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 35));
	    NumberLable2.setBounds(552, 172, 24, 45);
	    getContentPane().add(NumberLable2);
	    
	    JLabel NumberLable3 = new JLabel("1");
	    NumberLable3.setForeground(new Color(255, 255, 204));
	    NumberLable3.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 35));
	    NumberLable3.setBounds(435, 391, 24, 45);
	    getContentPane().add(NumberLable3);
	    
	    JLabel NumberLable4 = new JLabel("3");
	    NumberLable4.setForeground(new Color(255, 255, 204));
	    NumberLable4.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 35));
	    NumberLable4.setBounds(653, 352, 24, 45);
	    getContentPane().add(NumberLable4);
        
        //GreenAreaName 右边小框的绿色地区名
	    JLabel GreenAreaName = new JLabel("Le Quartier Administratif"); 
	    GreenAreaName.setForeground(new Color(128, 0, 0));
	    GreenAreaName.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 35));
	    GreenAreaName.setBounds(808, 71, 373, 45);
	    getContentPane().add(GreenAreaName);
	    GreenAreaName.setVisible(false);//默认状态下不可见，在点击GreenAreaButton后可见
	    
	    //GreenAreaName 右边小框的橙色地区名
	    JLabel OrangeAreaName = new JLabel("Le Bureau des Etudiants"); //这是右边小框的地区名
	    OrangeAreaName.setForeground(new Color(128, 0, 0));
	    OrangeAreaName.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 35));
	    OrangeAreaName.setBounds(808, 71, 373, 45);
	    getContentPane().add(OrangeAreaName);
	    OrangeAreaName.setVisible(false);//默认状态下不可见，在点击GreenAreaButton后可见
        
        //ReadyButton
        JButton ReadyButton = new JButton("");
        ReadyButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		setVisible(false);
        		finalframe.setVisible(true);
        	}
        });
        ReadyButton.setIcon(new ImageIcon(TreveFrame.class.getResource("/imgs/play_ready_icon.png")));
        ReadyButton.setBounds(1215, 548, 107, 43);
        getContentPane().add(ReadyButton);
        
        JButton PinkAreaLoseButton = new JButton("");
        PinkAreaLoseButton.setToolTipText("Vous avez perdu La Halle Sportive");
        PinkAreaLoseButton.setIcon(new ImageIcon(TreveFrame.class.getResource("/imgs/PinkAreaLoseButton.png")));
        PinkAreaLoseButton.setBounds(263, 430, 84, 87);
        getContentPane().add(PinkAreaLoseButton);
        
       //删除按钮1
        JButton DeleteButton1 = new JButton("");
        DeleteButton1.setIcon(new ImageIcon(TreveFrame.class.getResource("/imgs/delete_icon.png")));
        DeleteButton1.setBounds(797, 126, 23, 25);
        getContentPane().add(DeleteButton1);
        DeleteButton1.setVisible(false);
        
        //删除按钮2
        DeleteButton2.setIcon(new ImageIcon(TreveFrame.class.getResource("/imgs/delete_icon.png")));
        DeleteButton2.setBounds(1044, 126, 23, 25);
        getContentPane().add(DeleteButton2);
        DeleteButton2.setVisible(false);
        DeleteButton2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		Soldat9Button.setVisible(false);
        		Soldat6Button.setVisible(true);
        		DeleteButton2.setVisible(false);
        	}
        });
        
       //删除按钮3
        JButton DeleteButton3 = new JButton("");
        DeleteButton3.setIcon(new ImageIcon(TreveFrame.class.getResource("/imgs/delete_icon.png")));
        DeleteButton3.setBounds(1170, 126, 23, 25);
        getContentPane().add(DeleteButton3);
        DeleteButton3.setVisible(false);
        DeleteButton3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		Soldat11Button.setVisible(false);
        		Soldat6Button.setVisible(true);
        		DeleteButton2.setVisible(false);
        		DeleteButton3.setVisible(false);
        	}
        });
        
        
        JButton Soldat1Button = new JButton("");
        Soldat1Button.setIcon(new ImageIcon(TreveFrame.class.getResource("/imgs/soldat1small.png")));
        Soldat1Button.setBounds(73, 750, 95, 115);
        getContentPane().add(Soldat1Button);
        
        JButton Soldat2Button = new JButton("");
        Soldat2Button.setIcon(new ImageIcon(TreveFrame.class.getResource("/imgs/soldat2small.png")));
        Soldat2Button.setBounds(197, 750, 95, 115);
        getContentPane().add(Soldat2Button);
        
        JButton Soldat3Button = new JButton("");
        Soldat3Button.setIcon(new ImageIcon(TreveFrame.class.getResource("/imgs/soldat1small.png")));
        Soldat3Button.setBounds(331, 750, 95, 115);
        getContentPane().add(Soldat3Button);
        
        JButton Soldat4Button = new JButton("");
        Soldat4Button.setIcon(new ImageIcon(TreveFrame.class.getResource("/imgs/soldat2small.png")));
        Soldat4Button.setBounds(460, 750, 95, 115);
        getContentPane().add(Soldat4Button);
        
        JButton Soldat5Button = new JButton("");
        Soldat5Button.setIcon(new ImageIcon(TreveFrame.class.getResource("/imgs/soldat2small.png")));
        Soldat5Button.setBounds(594, 750, 95, 115);
        getContentPane().add(Soldat5Button);
        Soldat5Button.addActionListener(new ActionListener() { //点击OrangeAreaButton触发事件
        	public void actionPerformed(ActionEvent e) {
        		Soldat11Button.setVisible(true);
        		Soldat5Button.setVisible(false);
        		DeleteButton3.setVisible(true);
        	}
        });
        
        Soldat6Button.setIcon(new ImageIcon(TreveFrame.class.getResource("/imgs/soldat2small.png")));
        Soldat6Button.setBounds(729, 750, 95, 115);
        getContentPane().add(Soldat6Button);
        Soldat6Button.setVisible(false);
        Soldat6Button.addActionListener(new ActionListener() { //点击OrangeAreaButton触发事件
        	public void actionPerformed(ActionEvent e) {
        		GreenAreaName.setVisible(false);
        		OrangeAreaName.setVisible(true);
        		Soldat9Button.setVisible(true);
        		Soldat6Button.setVisible(false);
        		DeleteButton2.setVisible(true);
        	}
        });
        
        JButton Soldat7Button = new JButton("");
        Soldat7Button.setIcon(new ImageIcon(TreveFrame.class.getResource("/imgs/soldat2dead.png")));
        Soldat7Button.setBounds(808, 137, 95, 115);
        getContentPane().add(Soldat7Button);
        Soldat7Button.setVisible(false);
        
        JButton Soldat8Button = new JButton("");
        Soldat8Button.setIcon(new ImageIcon(TreveFrame.class.getResource("/imgs/soldat2dead.png")));
        Soldat8Button.setBounds(929, 137, 95, 115);
        getContentPane().add(Soldat8Button);
        Soldat8Button.setVisible(false);
        
        Soldat9Button.setIcon(new ImageIcon(TreveFrame.class.getResource("/imgs/soldat1small.png")));
        Soldat9Button.setBounds(1054, 137, 95, 115);
        getContentPane().add(Soldat9Button);
        Soldat9Button.setVisible(false);
        
        JButton Soldat10Button = new JButton("");
        Soldat10Button.setIcon(new ImageIcon(TreveFrame.class.getResource("/imgs/soldat1small.png")));
        Soldat10Button.setBounds(808, 137, 95, 115);
        getContentPane().add(Soldat10Button);
        Soldat10Button.setVisible(false);
        
        
        Soldat11Button.setIcon(new ImageIcon(TreveFrame.class.getResource("/imgs/soldat2small.png")));
        Soldat11Button.setBounds(1180, 137, 95, 115);
        getContentPane().add(Soldat11Button);
        Soldat11Button.setVisible(false);
        
        
        //绿色小红旗按钮
        JButton GreenAreaWinButton = new JButton("");
        GreenAreaWinButton.setToolTipText("Vous avez occupé Le Quartier Administratif !");
        GreenAreaWinButton.setIcon(new ImageIcon(TreveFrame.class.getResource("/imgs/GreenAreaWinButton.png")));
        GreenAreaWinButton.setBounds(285, 159, 91, 87);
        getContentPane().add(GreenAreaWinButton);
        GreenAreaWinButton.addActionListener(new ActionListener() { //点击GreenAreaButton触发事件
        	public void actionPerformed(ActionEvent e) {
        		GreenAreaName.setVisible(true);
        		OrangeAreaName.setVisible(false);
        		Soldat7Button.setVisible(true);
        		Soldat8Button.setVisible(true);
        		Soldat9Button.setVisible(true);
        		Soldat11Button.setVisible(true);
        		DeleteButton2.setVisible(false);
        		DeleteButton1.setVisible(false);
        		DeleteButton3.setVisible(true);
        	}
        });
        
      //OrangeAreaButton橙色地区按钮
	    JButton OrangeAreaButton = new JButton("");
	    OrangeAreaButton.setIcon(new ImageIcon(TreveFrame.class.getResource("/imgs/OrangeAreaButtonNew.png")));
	    OrangeAreaButton.setBounds(501, 149, 112, 97);
	    getContentPane().add(OrangeAreaButton);
	    OrangeAreaButton.addActionListener(new ActionListener() { //点击OrangeAreaButton触发事件
        	public void actionPerformed(ActionEvent e) {
        		GreenAreaName.setVisible(false);
        		OrangeAreaName.setVisible(true);
        		DeleteButton1.setVisible(true);
        		Soldat7Button.setVisible(false);
        		Soldat10Button.setVisible(true);
        		Soldat8Button.setVisible(true);
        		Soldat9Button.setVisible(false);
        	}
        });
        
        JLabel RéservistesText = new JLabel("Réservistes :");
        RéservistesText.setForeground(new Color(255, 218, 185));
        RéservistesText.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 35));
        RéservistesText.setBounds(73, 690, 191, 63);
        getContentPane().add(RéservistesText);
        
        JLabel GuideText = new JLabel("Cliquez sur la région pour voir les soldats, cliquez sur la réserve pour les placer dans cette région.");
        GuideText.setForeground(SystemColor.info);
        GuideText.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
        GuideText.setBounds(67, 648, 1272, 45);
        getContentPane().add(GuideText);
        
        JLabel GuideText2 = new JLabel("* Les chiffres sur la carte vous indiquent\r\n");
	    GuideText2.setForeground(new Color(128, 0, 0));
	    GuideText2.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
	    GuideText2.setBounds(698, 523, 487, 45);
	    getContentPane().add(GuideText2);
	    
	    JLabel guideText3 = new JLabel(" combien de soldats se trouvent dans la zone.");
	    guideText3.setForeground(new Color(128, 0, 0));
	    guideText3.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
	    guideText3.setBounds(696, 564, 538, 36);
	    getContentPane().add(guideText3);
        
        
        //backgroundLable
        JLabel backgroundLable = new JLabel("");
        backgroundLable.setIcon(new ImageIcon(TreveFrame.class.getResource("/imgs/background6.png")));
        backgroundLable.setBounds(0, 0, 1384, 961);
        getContentPane().add(backgroundLable);
	}
}
