package Bataille;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MeleeFrameback2 extends JFrame{

	private JFrame frame;
	
	TreveFrame treveframe=new TreveFrame();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MeleeFrameback2 window = new MeleeFrameback2();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MeleeFrameback2() {
		treveframe.setVisible(false);
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Melée Frame");
        setBounds(100, 100, 1400, 1000);
        getContentPane().setLayout(null);
        
        JLabel GuideText1 = new JLabel("La barre rouge représente les points de vies de l'ennemi.");
        GuideText1.setForeground(new Color(128, 0, 0));
        GuideText1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
        GuideText1.setBounds(42, 892, 742, 40);
        getContentPane().add(GuideText1);
        
        JLabel GuideText2 = new JLabel("La barre bleue représente vos propres points de vies.");
        GuideText2.setForeground(new Color(128, 0, 0));
        GuideText2.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
        GuideText2.setBounds(730, 892, 742, 40);
        getContentPane().add(GuideText2);
        
        JLabel GuideText3 = new JLabel("Cliquez sur une barre pour connaître l'état exact de la bataille dans la zone.");
        GuideText3.setForeground(new Color(128, 0, 0));
        GuideText3.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 35));
        GuideText3.setBounds(277, 38, 1097, 40);
        getContentPane().add(GuideText3);
        
        
        
        //background
        JLabel BackgroundLabel1 = new JLabel("");
        BackgroundLabel1.setIcon(new ImageIcon(MeleeFrame.class.getResource("/imgs/background4.png")));
        BackgroundLabel1.setBounds(0, -14, 1400, 1000);
        getContentPane().add(BackgroundLabel1);
        
        
        //label pour continuer
        JLabel ContinuerLabel = new JLabel("");
        ContinuerLabel.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		setVisible(false);
        		treveframe.setVisible(true);
        	}
        });
        ContinuerLabel.setBackground(new Color(219, 241, 205));
        ContinuerLabel.setBounds(1101, 586, 283, 375);
        getContentPane().add(ContinuerLabel);
	}
}
