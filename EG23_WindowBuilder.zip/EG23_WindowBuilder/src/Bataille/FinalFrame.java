package Bataille;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class FinalFrame extends JFrame{

	private JFrame frame;
	StartFrame startframe=new StartFrame();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FinalFrame window = new FinalFrame();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FinalFrame() {
		startframe.setVisible(false);
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Final Frame");//Définition du titre de la fenêtre à "Final Frame"
        setBounds(100, 100, 1400, 1000);
        getContentPane().setLayout(null);
        
        //返回按钮
        // Création du bouton de retour sans texte pour retour
        JButton BackButton = new JButton("");
        BackButton.setIcon(new ImageIcon(FinalFrame.class.getResource("/imgs/return.png")));
        BackButton.setBounds(1266, 876, 118, 85);
        getContentPane().add(BackButton);
        BackButton.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		// Rendre visible le cadre de départ et cacher le cadre actuel
	    		startframe.setVisible(true);
	    		setVisible(false);
	    	}
	    });
        
        //win, Création d'une étiquette pour le fond avec l'image de victoire
        JLabel BackgroundLabel1 = new JLabel("");
        BackgroundLabel1.setIcon(new ImageIcon(FinalFrame.class.getResource("/imgs/win.png")));
        BackgroundLabel1.setBounds(0, -14, 1400, 1000);
        getContentPane().add(BackgroundLabel1);
        
        
        
	}

}
