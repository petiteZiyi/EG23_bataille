package Bataille;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.SystemColor;

public class CombatFrame extends JFrame{

	private JFrame frame;

	MeleeFrame meleeframe = new MeleeFrame();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CombatFrame window = new CombatFrame();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CombatFrame() {
		meleeframe.setVisible(false);
		initialize();
	}
	
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Combat Frame");// Définition du titre de la fenêtre à "Combat Frame"
        setBounds(100, 100, 1400, 1000);
        getContentPane().setLayout(null);
        // Création de trois boutons de soldat，sans définition d'icônes ou de texte
        JButton Soldat1Button = new JButton("");
	    JButton Soldat2Button = new JButton("");
	    JButton Soldat3Button = new JButton("");
	    // Création de deux étiquettes pour afficher les informations d'état des soldats, sans contenu spécifique
        JLabel Soldat1Lable = new JLabel("");
        JLabel Soldat3Label = new JLabel("");
	    
        // Création et configuration d'une étiquette pour afficher le nombre "0"
	    JLabel NumberLable1 = new JLabel("0");
	    NumberLable1.setForeground(new Color(255, 255, 204));
	    NumberLable1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 35));
	    NumberLable1.setBounds(327, 199, 24, 45);
	    getContentPane().add(NumberLable1);
        
	    // Création et configuration d'une étiquette pour afficher le nombre "0"
	    JLabel NumberLable2 = new JLabel("0");
	    NumberLable2.setForeground(new Color(255, 255, 204));
	    NumberLable2.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 35));
	    NumberLable2.setBounds(506, 212, 24, 45);
	    getContentPane().add(NumberLable2);
        
	    // Création et configuration d'une étiquette pour afficher le nombre "4"
	    JLabel NumberLable3 = new JLabel("4");
	    NumberLable3.setForeground(new Color(255, 255, 204));
	    NumberLable3.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 35));
	    NumberLable3.setBounds(295, 444, 24, 45);
	    getContentPane().add(NumberLable3);
	    
	    // Création et configuration d'une étiquette pour afficher le nombre "2"
	    JLabel NumberLable4 = new JLabel("2");
	    NumberLable4.setForeground(new Color(255, 255, 204));
	    NumberLable4.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 35));
	    NumberLable4.setBounds(438, 397, 24, 45);
	    getContentPane().add(NumberLable4);
	    
	    // Création et configuration d'une étiquette pour afficher le nombre "5"
	    JLabel NumberLable5 = new JLabel("5");
	    NumberLable5.setForeground(new Color(255, 255, 204));
	    NumberLable5.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 35));
	    NumberLable5.setBounds(655, 359, 24, 45);
	    getContentPane().add(NumberLable5);
	    
        //士兵1的删除键
	    // Création du bouton de suppression1
	    JButton DeleteButton1 = new JButton("");
	    DeleteButton1.setIcon(new ImageIcon(CombatFrame.class.getResource("/imgs/delete_icon.png")));
	    DeleteButton1.setBounds(814, 140, 24, 25);
	    getContentPane().add(DeleteButton1);
	    DeleteButton1.setVisible(false);// Le bouton de suppression est invisible par défaut
	    // Ajout d'un écouteur d'événements pour le bouton de suppression
	    DeleteButton1.addActionListener(new ActionListener() { //点击GreenAreaButton触发事件
        	public void actionPerformed(ActionEvent e) {
        		Soldat1Button.setVisible(true);// Affichage du bouton Soldat1 après un clic sur le bouton de suppression
	    		Soldat1Lable.setVisible(false);// Cache de l'étiquette Soldat1
	    		DeleteButton1.setVisible(false);// Cache de l'étiquette Soldat1
	    		NumberLable1.setText("0");// Réinitialisation de l'étiquette du nombre à "0"
        	}
        });
	    
	    //士兵3的删除键
	    // Création du bouton de suppression2
	    JButton DeleteButton3 = new JButton("");
	    DeleteButton3.setIcon(new ImageIcon(CombatFrame.class.getResource("/imgs/delete_icon.png")));
	    DeleteButton3.setBounds(939, 142, 24, 23);
	    getContentPane().add(DeleteButton3);
	    DeleteButton3.setVisible(false);

	    
        //右边小框里的士兵1
	    //Configuration de l'icône pour l'étiquette Soldat1
	    Soldat1Lable.setIcon(new ImageIcon(CombatFrame.class.getResource("/imgs/soldat1small.png")));
	    Soldat1Lable.setBounds(824, 150, 95, 115);
	    getContentPane().add(Soldat1Lable);
	    Soldat1Lable.setVisible(false);// Cache de l'étiquette Soldat1
	    // Ajout d'un écouteur d'événements de clic de souris pour l'étiquette Soldat1
	    Soldat1Lable.addMouseListener(new MouseAdapter() {//点击小框里的士兵1可以删除
	    	@Override
	    	public void mouseClicked(MouseEvent e) {
	    		Soldat1Button.setVisible(true);// Affichage du bouton Soldat1 lorsque l'étiquette Soldat1 est cliquée
	    		Soldat1Lable.setVisible(false);// Cache de l'étiquette Soldat1
	    	}
	    });
	   
	    //右边小框里的士兵2
	    //Soldat2Label
	    JLabel Soldat2Label = new JLabel("");
	    Soldat2Label.addMouseListener(new MouseAdapter() {
	    	@Override
	    	public void mouseClicked(MouseEvent e) {  //点击小框里的士兵2可以删除
	    		Soldat2Button.setVisible(true);
	    		Soldat2Label.setVisible(false);
	    		DeleteButton1.setVisible(false);
	    	}
	    });
	    Soldat2Label.setIcon(new ImageIcon(CombatFrame.class.getResource("/imgs/soldat2small.png")));
	    Soldat2Label.setBounds(824, 150, 95, 115);
	    getContentPane().add(Soldat2Label);
	    Soldat2Label.setVisible(false);
	    
	    JButton PauseButton = new JButton("");
	    PauseButton.setBorderPainted(false);
	    PauseButton.setIcon(new ImageIcon(CombatFrame.class.getResource("/imgs/pause.png")));
	    PauseButton.setBounds(29, 62, 65, 65);
	    getContentPane().add(PauseButton);
	    
	    
	    //右边小框里的士兵3
	    //Soldat3Label
	    Soldat3Label.setIcon(new ImageIcon(CombatFrame.class.getResource("/imgs/soldat3small.png")));
	    Soldat3Label.setBounds(950, 150, 95, 115);
	    getContentPane().add(Soldat3Label);
	    Soldat3Label.setVisible(false);
	    Soldat3Label.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		Soldat3Button.setVisible(true);
	    		Soldat3Label.setVisible(false);
	    		DeleteButton3.setVisible(false);
        	}
        });
	    
	    //下方框内的士兵1
	    //Soldat1Button
	    Soldat1Button.setIcon(new ImageIcon(CombatFrame.class.getResource("/imgs/soldat1small.png")));
	    Soldat1Button.setBounds(77, 697, 95, 115);
	    getContentPane().add(Soldat1Button);
	    // Configuration de l'info-bulle du bouton Soldat1, utilisation du format HTML pour le retour à la ligne
	    Soldat1Button.setToolTipText("<html>Point de vie 30<br>Force 10</html>");//鼠标放在按钮上浮现的说明框 用html实现换行
	    // Ajout d'un écouteur d'événements de clic pour le bouton Soldat1
	    Soldat1Button.addActionListener(new ActionListener() { //点击Soldat1Button将下方的Soldat1Button按钮隐藏，小框中的Soldat11Button显示。
        	public void actionPerformed(ActionEvent e) {
        		Soldat1Button.setVisible(false);// Cache le bouton Soldat1 après le clic
        		Soldat1Lable.setVisible(true);// Affiche l'étiquette associée à Soldat1
        		DeleteButton1.setVisible(true);// Affiche le bouton de suppression
        		NumberLable1.setText("1");// Définit et affiche l'étiquette du nombre à "1"
        	}
        });
	    
	    //下方框内的士兵2
	    //Soldat2Button
	    Soldat2Button.setIcon(new ImageIcon(CombatFrame.class.getResource("/imgs/soldat2small.png")));
	    Soldat2Button.setBounds(195, 697, 95, 115);
	    getContentPane().add(Soldat2Button);
	    Soldat2Button.setToolTipText("<html>Point de vie 30<br>Force 10</html>");
	    Soldat2Button.addActionListener(new ActionListener() { //点击Soldat2Button将下方的Soldat1Button按钮隐藏，小框中的Soldat11Button显示。
        	public void actionPerformed(ActionEvent e) {
        		Soldat2Button.setVisible(false);   //自己本身消失
        		Soldat2Label.setVisible(true);
        		DeleteButton1.setVisible(true);
        		NumberLable2.setText("1");
        	}
        });
	    
	    //下方框内的士兵3
	    //Soldat3Button
	    Soldat3Button.setIcon(new ImageIcon(CombatFrame.class.getResource("/imgs/soldat3small.png")));
	    Soldat3Button.setBounds(317, 697, 95, 115);
	    getContentPane().add(Soldat3Button);
	    Soldat3Button.setToolTipText("<html>Point de vie 30<br>Force 10</html>");
	    Soldat3Button.addActionListener(new ActionListener() { //点击Soldat3Button将下方的Soldat1Button按钮隐藏，小框中的Soldat11Button显示。
        	public void actionPerformed(ActionEvent e) {
        		Soldat3Button.setVisible(false);   //自己本身消失
        		Soldat3Label.setVisible(true);
        		DeleteButton3.setVisible(true);
        		NumberLable2.setText("2");
        	}
        });
	    
	    //Soldat4Button
	    JButton Soldat4Button = new JButton("");
	    Soldat4Button.setIcon(new ImageIcon(CombatFrame.class.getResource("/imgs/soldat1small.png")));
	    Soldat4Button.setBounds(438, 697, 95, 115);
	    getContentPane().add(Soldat4Button);
	    Soldat4Button.addActionListener(new ActionListener() { //点击Soldat4Button将下方的Soldat1Button按钮隐藏，小框中的Soldat11Button显示。
        	public void actionPerformed(ActionEvent e) {
        		Soldat4Button.setVisible(false);   //自己本身消失
        	}
        });
	    
	    //Soldat5Button
	    JButton Soldat5Button = new JButton("");
	    Soldat5Button.setIcon(new ImageIcon(CombatFrame.class.getResource("/imgs/soldat2small.png")));
	    Soldat5Button.setBounds(569, 697, 95, 115);
	    getContentPane().add(Soldat5Button);
	    Soldat5Button.addActionListener(new ActionListener() { //点击Soldat1Button将下方的Soldat1Button按钮隐藏，小框中的Soldat11Button显示。
        	public void actionPerformed(ActionEvent e) {
        		Soldat5Button.setVisible(false);   //自己本身消失
        	}
        });
	    
	    //Soldat6Button
	    JButton Soldat6Button = new JButton("");
	    Soldat6Button.setIcon(new ImageIcon(CombatFrame.class.getResource("/imgs/soldat3small.png")));
	    Soldat6Button.setBounds(698, 697, 95, 115);
	    getContentPane().add(Soldat6Button);
	    Soldat6Button.addActionListener(new ActionListener() { //点击Soldat6Button将下方的Soldat1Button按钮隐藏，小框中的Soldat11Button显示。
        	public void actionPerformed(ActionEvent e) {
        		Soldat6Button.setVisible(false);   //自己本身消失
        	}
        });
	    
	    //Soldat7Button
	    JButton Soldat7Button = new JButton("");
	    Soldat7Button.setIcon(new ImageIcon(CombatFrame.class.getResource("/imgs/soldat1small.png")));
	    Soldat7Button.setBounds(824, 697, 95, 115);
	    getContentPane().add(Soldat7Button);
	    
	    //Soldat8Button
	    JButton Soldat8Button = new JButton("");
	    Soldat8Button.setIcon(new ImageIcon(CombatFrame.class.getResource("/imgs/soldat2small.png")));
	    Soldat8Button.setBounds(950, 697, 95, 115);
	    getContentPane().add(Soldat8Button);
	    
	    //Soldat9Button
	    JButton Soldat9Button = new JButton("");
	    Soldat9Button.setIcon(new ImageIcon(CombatFrame.class.getResource("/imgs/soldat3small.png")));
	    Soldat9Button.setBounds(1075, 697, 95, 115);
	    getContentPane().add(Soldat9Button);
	    
	    //Soldat10Button
	    JButton Soldat10Button = new JButton("");
	    Soldat10Button.setIcon(new ImageIcon(CombatFrame.class.getResource("/imgs/soldat1small.png")));
	    Soldat10Button.setBounds(1205, 697, 95, 115);
	    getContentPane().add(Soldat10Button);
	    JLabel TenSoldats = new JLabel("");
	    TenSoldats.setIcon(new ImageIcon(CombatFrame.class.getResource("/imgs/tenSoldats.png")));
	    TenSoldats.setBounds(74, 822, 1234, 129);
	    getContentPane().add(TenSoldats);
	    
	    //GreenAreaName 右边小框的绿色地区名
	    // Définition d'une étiquette pour afficher le nom de la zone verte
	    JLabel GreenAreaName = new JLabel("Le Quartier Administratif"); 
	    GreenAreaName.setForeground(new Color(128, 0, 0));// Définition de la couleur de premier plan de l'étiquette en rouge foncé
	    GreenAreaName.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 35));
	    GreenAreaName.setBounds(808, 71, 373, 45);
	    getContentPane().add(GreenAreaName);
	    // L'étiquette est invisible par défaut et devient visible après un clic sur le bouton de la zone verte
	    GreenAreaName.setVisible(false);//默认状态下不可见，在点击GreenAreaButton后可见
	    
	    //GreenAreaName 右边小框的橙色地区名
	    // Définition d'une étiquette pour afficher le nom de la zone orange
	    JLabel OrangeAreaName = new JLabel("Le Bureau des Etudiants"); //这是右边小框的地区名
	    OrangeAreaName.setForeground(new Color(128, 0, 0));
	    OrangeAreaName.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 35));
	    OrangeAreaName.setBounds(808, 71, 373, 45);
	    getContentPane().add(OrangeAreaName);
	    // L'étiquette est invisible par défaut et devient visible après un clic sur le bouton de la zone orange
	    OrangeAreaName.setVisible(false);//默认状态下不可见，在点击GreenAreaButton后可见

	    
	    //GreenAreaButton绿色地区按钮
	    // Création d'un bouton pour la zone verte
	    JButton GreenAreaButton = new JButton("");
	    GreenAreaButton.setIcon(new ImageIcon(CombatFrame.class.getResource("/imgs/GreenAreaButton.png")));
	    GreenAreaButton.setBounds(284, 178, 103, 95);
	    getContentPane().add(GreenAreaButton);
	    //Ajout d'un écouteur d'événements de clic pour le bouton de la zone verte
	    GreenAreaButton.addActionListener(new ActionListener() { 
        	public void actionPerformed(ActionEvent e) {
        		GreenAreaName.setVisible(true);
        		OrangeAreaName.setVisible(false);
        	}
        });
	    
	    
	   //OrangeAreaButton橙色地区按钮
	    // Création d'un bouton pour la zone orange
	    JButton OrangeAreaButton = new JButton("");
	    OrangeAreaButton.setIcon(new ImageIcon(CombatFrame.class.getResource("/imgs/OrangeAreaButton.png")));
	    OrangeAreaButton.setBounds(471, 165, 103, 108);
	    getContentPane().add(OrangeAreaButton);
	    // Ajout d'un écouteur d'événements de clic pour le bouton de la zone orange
	    OrangeAreaButton.addActionListener(new ActionListener() { //点击OrangeAreaButton触发事件
        	public void actionPerformed(ActionEvent e) {
        		GreenAreaName.setVisible(false);
        		OrangeAreaName.setVisible(true);
        		Soldat1Lable.setVisible(false);
        		DeleteButton1.setVisible(false);
        	}
        });
	    

	    // ReadyButton跳转页面，用于玩家确认准备完毕并跳转到下一个页面
	    // Création d'un bouton JButton pour que le joueur confirme qu'il est prêt et passe à la page suivante
	    JButton ReadyButton = new JButton("");
	    ReadyButton.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		meleeframe.setVisible(true); // Affichage de la fenêtre suivante
        		setVisible(false);   // Cacher la fenêtre actuelle
	    	}
	    });
	    ReadyButton.setIcon(new ImageIcon(CombatFrame.class.getResource("/imgs/play_ready_icon.png")));
	    ReadyButton.setBounds(1223, 550, 107, 43);
	    getContentPane().add(ReadyButton);
	    
	    JLabel GuideText = new JLabel("Cliquez sur la région sur la carte, puis cliquez sur le soldat pour l'affecter à cette région.");
	    GuideText.setForeground(SystemColor.info);
	    GuideText.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
	    GuideText.setBounds(77, 653, 1091, 34);
	    getContentPane().add(GuideText);
	    
	    JLabel GuideText2 = new JLabel("* Les chiffres sur la carte vous indiquent\r\n");
	    GuideText2.setForeground(new Color(128, 0, 0));
	    GuideText2.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
	    GuideText2.setBounds(698, 523, 487, 45);
	    getContentPane().add(GuideText2);
	    
	    JLabel guideText3 = new JLabel(" combien de soldats se trouvent dans la zone.");
	    guideText3.setForeground(new Color(128, 0, 0));
	    guideText3.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
	    guideText3.setBounds(696, 564, 538, 36);
	    getContentPane().add(guideText3);
	    
	    //背景 Création d'un JLabel pour servir de fond
	    JLabel BackgroundLabel1 = new JLabel("");
	    BackgroundLabel1.setIcon(new ImageIcon(CombatFrame.class.getResource("/imgs/background3.png")));
	    BackgroundLabel1.setBounds(0, 0, 1384, 961);
	    getContentPane().add(BackgroundLabel1);
		
	}
}
