package Bataille;

import java.awt.EventQueue;
import javax.swing.*;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.concurrent.atomic.AtomicInteger;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JLayeredPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.SystemColor;


public class PlayFrame extends JFrame{

	private JFrame frame;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	CombatFrame combatframe = new CombatFrame();
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PlayFrame window = new PlayFrame();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PlayFrame() {
		combatframe.setVisible(false);
		initialize();
	}

	public void calculer(AtomicInteger nombrepoint,AtomicInteger value,boolean plus) {
		if(plus) {
			nombrepoint.getAndDecrement();  // nombrepoint 减 1
	        value.getAndIncrement();        // value 加 1
			
		}
		else {
			nombrepoint.getAndIncrement();  // nombrepoint 加 1
	        value.getAndDecrement();        // value 减 1
		}
	}
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		AtomicInteger nombrepoint = new AtomicInteger(400);
		
		JLabel PauseLabel = new JLabel("");
		JButton PauseButton = new JButton("");
        JButton Go_onButton = new JButton("");
        Go_onButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		PauseLabel.setVisible(false);
				Go_onButton.setVisible(false);
        	}
        });
		PauseButton.setBorderPainted(false);
		PauseButton.setForeground(new Color(240, 255, 240));
		PauseButton.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/pause.png")));
		JLabel NombrePointLable = new JLabel();
		JLabel FValue = new JLabel();      
		JLabel DValue = new JLabel();
        JLabel RValue = new JLabel();
        JLabel CValue = new JLabel();
        JLabel IValue = new JLabel();
        JLabel PValue = new JLabel();
		AtomicInteger pvalue = new AtomicInteger(30);
        AtomicInteger fvalue = new AtomicInteger(0);
        AtomicInteger dvalue = new AtomicInteger(0);
        AtomicInteger rvalue = new AtomicInteger(0);
        AtomicInteger cvalue = new AtomicInteger(0);
        AtomicInteger ivalue = new AtomicInteger(0);

		
		setTitle("Play Frame");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1400, 1000);
        getContentPane().setLayout(null);
        
        //PauseLabel
        
        PauseLabel.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/pausebig.jpg")));
        PauseLabel.setBounds(0, 0, 1384, 961);
        getContentPane().add(PauseLabel);
        PauseLabel.setVisible(false);
        
        //PauseButton
        PauseButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PauseLabel.setVisible(true);
				Go_onButton.setVisible(true);
			}
		});
        
        //下方士兵们
        JLabel fiveLabel2 = new JLabel("");
        fiveLabel2.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/fiveSoldats.png")));
        fiveLabel2.setBounds(67, 807, 618, 143);
        getContentPane().add(fiveLabel2);
        
        JLabel fiveLabel1 = new JLabel("");
        fiveLabel1.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/fiveSoldats.png")));
        fiveLabel1.setBounds(696, 697, 638, 115);
        getContentPane().add(fiveLabel1);
        
        JLabel fiveLabel3 = new JLabel("");
        fiveLabel3.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/fiveSoldats.png")));
        fiveLabel3.setBounds(695, 822, 618, 115);
        getContentPane().add(fiveLabel3);
        
        
        JButton Soldat1Button = new JButton("");
        Soldat1Button.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/soldat1small.png")));
        Soldat1Button.setBounds(73, 695, 95, 115);
        getContentPane().add(Soldat1Button);
        
        JButton Soldat2Button = new JButton("");
        Soldat2Button.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		pvalue.set(30);
        		PValue.setText(String.valueOf(pvalue.get()));
        		fvalue.set(0);
        		FValue.setText(String.valueOf(fvalue.get()));
        		dvalue.set(0);
        		DValue.setText(String.valueOf(dvalue.get()));
        		rvalue.set(0);
        		RValue.setText(String.valueOf(rvalue.get()));
        		cvalue.set(0);
        		CValue.setText(String.valueOf(cvalue.get()));
        		ivalue.set(0);
        		IValue.setText(String.valueOf(ivalue.get()));
        	}
        });
        Soldat2Button.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/soldat2small.png")));
        Soldat2Button.setBounds(192, 695, 95, 115);
        getContentPane().add(Soldat2Button);
        
        JButton Soldat3Button = new JButton("");
        Soldat3Button.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/soldat3small.png")));
        Soldat3Button.setBounds(316, 695, 95, 115);
        getContentPane().add(Soldat3Button);
        
        JButton Soldat4Button = new JButton("");
        Soldat4Button.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/soldat1small.png")));
        Soldat4Button.setBounds(434, 695, 95, 115);
        getContentPane().add(Soldat4Button);
        
        JButton Soldat5Button = new JButton("");
        Soldat5Button.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/soldat2small.png")));
        Soldat5Button.setBounds(563, 695, 95, 115);
        getContentPane().add(Soldat5Button);
        

        JRadioButton rdbtnNewRadioButton = new JRadioButton("Défence");
        rdbtnNewRadioButton.setBackground(new Color(255, 245, 212));
        buttonGroup.add(rdbtnNewRadioButton);
        rdbtnNewRadioButton.setForeground(new Color(128, 0, 0));
        rdbtnNewRadioButton.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 25));
        rdbtnNewRadioButton.setBounds(947, 422, 99, 42);
        getContentPane().add(rdbtnNewRadioButton);
        
        
        //PValue 显示Point de vie的值，
        PValue.setText(String.valueOf(pvalue.get()));
        PValue.setForeground(new Color(128, 0, 0));
        PValue.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 25));
        PValue.setBounds(1149, 130, 35, 25);
        getContentPane().add(PValue);
        
        //Fvalue
        FValue.setText(String.valueOf(fvalue.get()));
        FValue.setForeground(new Color(128, 0, 0));
        FValue.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 25));
        FValue.setBounds(1150, 181, 35, 25);
        getContentPane().add(FValue);
        
        //DValue
        DValue.setText(String.valueOf(dvalue.get()));
        DValue.setForeground(new Color(128, 0, 0));
        DValue.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 25));
        DValue.setBounds(1150, 232, 35, 25);
        getContentPane().add(DValue);
        
        //RValue
        RValue.setText(String.valueOf(rvalue.get()));
        RValue.setForeground(new Color(128, 0, 0));
        RValue.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 25));
        RValue.setBounds(1150, 282, 35, 25);
        getContentPane().add(RValue);
        
        //CValue
        CValue.setText(String.valueOf(cvalue.get()));
        CValue.setForeground(new Color(128, 0, 0));
        CValue.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 25));
        CValue.setBounds(1149, 333, 35, 25);
        getContentPane().add(CValue);
        
        //IValue
        IValue.setText(String.valueOf(ivalue.get()));
        IValue.setForeground(new Color(128, 0, 0));
        IValue.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 25));
        IValue.setBounds(1150, 386, 35, 25);
        getContentPane().add(IValue);
        
        
        //PPlusButton用来控制Point de vie属性增加的按钮
        JButton PPlusButton = new JButton();
        PPlusButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		calculer(nombrepoint,pvalue,true);
        		NombrePointLable.setText(String.valueOf(nombrepoint.get()));
        		PValue.setText(String.valueOf(pvalue.get()));
        	}
        });
        PPlusButton.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/plus.png")));
        PPlusButton.setBounds(1206, 130, 30, 30);
        getContentPane().add(PPlusButton);
        
        //PMoinsButton 用来控制Point de vie属性减少的按钮
        JButton PMoinsButton = new JButton("");
        PMoinsButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		if(pvalue.get()>=31) {
        			calculer(nombrepoint,pvalue,false);
        			NombrePointLable.setText(String.valueOf(nombrepoint.get()));
        			PValue.setText(String.valueOf(pvalue.get()));
        		}
        		else {
        			JOptionPane.showMessageDialog(null, "La valeur de la vie ne peut être inférieure à 30!", "Information", JOptionPane.INFORMATION_MESSAGE);
        		}
        	}
        });
        PMoinsButton.setForeground(new Color(240, 255, 240));
        PMoinsButton.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/moins.png")));
        PMoinsButton.setBounds(1085, 130, 30, 27);
        getContentPane().add(PMoinsButton);
        
        
        JButton DPlusButton = new JButton("");
        DPlusButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		calculer(nombrepoint,dvalue,true);
        		NombrePointLable.setText(String.valueOf(nombrepoint.get()));
        		DValue.setText(String.valueOf(dvalue.get()));
        	}
        });
        DPlusButton.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/plus.png")));
        DPlusButton.setBounds(1206, 232, 30, 27);
        getContentPane().add(DPlusButton);
        
        JButton DMoinsButton = new JButton("");
        DMoinsButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		if(dvalue.get()>0) {
        			calculer(nombrepoint,dvalue,false);
        			NombrePointLable.setText(String.valueOf(nombrepoint.get()));
        			DValue.setText(String.valueOf(dvalue.get()));
        		}
        		else {
        			JOptionPane.showMessageDialog(null, "La valeur de la Dextérité ne peut être inférieure à 0!", "Information", JOptionPane.INFORMATION_MESSAGE);
        		}
        	}
        });
        DMoinsButton.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/moins.png")));
        DMoinsButton.setBounds(1085, 232, 30, 27);
        getContentPane().add(DMoinsButton);
        
        JButton FPlusButton = new JButton("");
        FPlusButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		calculer(nombrepoint,fvalue,true);
        		NombrePointLable.setText(String.valueOf(nombrepoint.get()));
        		FValue.setText(String.valueOf(fvalue.get()));
        	}
        });
        FPlusButton.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/plus.png")));
        FPlusButton.setBounds(1206, 181, 30, 27);
        getContentPane().add(FPlusButton);
        
        JButton FMoinButton = new JButton("");
        FMoinButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		if(fvalue.get()>=1) {
        			calculer(nombrepoint,fvalue,false);
        			NombrePointLable.setText(String.valueOf(nombrepoint.get()));
        			FValue.setText(String.valueOf(fvalue.get()));
        		}
        		else {
        			JOptionPane.showMessageDialog(null, "La valeur de la force ne peut être inférieure à 0!", "Information", JOptionPane.INFORMATION_MESSAGE);
        		}
        	}
        });
        FMoinButton.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/moins.png")));
        FMoinButton.setBounds(1085, 181, 30, 27);
        getContentPane().add(FMoinButton);
        
        
        //ReadyButton
        JButton ReadyButton = new JButton("");
        ReadyButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		combatframe.setVisible(true);
        		setVisible(false);
        	}
        });
        ReadyButton.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/play_ready_icon.png")));
        ReadyButton.setBounds(1206, 554, 107, 43);
        getContentPane().add(ReadyButton);
        
        
        //PauseButton
        PauseButton.setBounds(23, 66, 65, 65);
        getContentPane().add(PauseButton);
        
        //CaracteristiqueTextLable 士兵属性分配左边的文本
        JLabel CaracteristiqueTextLable = new JLabel("");
        CaracteristiqueTextLable.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/CaracteristiqueText.png")));
        CaracteristiqueTextLable.setBounds(786, 105, 246, 370);
        getContentPane().add(CaracteristiqueTextLable);
        
        JLabel SoldatsRestantsText = new JLabel("Nombre de soldats restants :");
        SoldatsRestantsText.setForeground(new Color(160, 82, 45));
        SoldatsRestantsText.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 35));
        SoldatsRestantsText.setBounds(762, 554, 423, 27);
        getContentPane().add(SoldatsRestantsText);
        
        JLabel NombreSoldatsLable = new JLabel("15");
        NombreSoldatsLable.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
        NombreSoldatsLable.setForeground(new Color(160, 82, 45));
        NombreSoldatsLable.setBounds(1149, 557, 30, 25);
        getContentPane().add(NombreSoldatsLable);
        
        JButton SaveButton = new JButton("");
        SaveButton.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/Play_Save_icon.png")));
        SaveButton.setBounds(1206, 473, 107, 40);
        getContentPane().add(SaveButton);
        
        //RMoinsButton
        JButton RMoinsButton = new JButton("");
        RMoinsButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		if(rvalue.get()>0) {
        			calculer(nombrepoint,rvalue,false);
        			NombrePointLable.setText(String.valueOf(nombrepoint.get()));
        			RValue.setText(String.valueOf(rvalue.get()));
        		}
    			else {
    				JOptionPane.showMessageDialog(null, "La valeur de la Résistance ne peut être inférieure à 0!", "Information", JOptionPane.INFORMATION_MESSAGE);
    			}
        	}
        });
        RMoinsButton.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/moins.png")));
        RMoinsButton.setBounds(1085, 280, 30, 27);
        getContentPane().add(RMoinsButton);
        
        JRadioButton rdbtnNewRadioButton_1_1 = new JRadioButton("Aléatoire");
        rdbtnNewRadioButton_1_1.setBackground(new Color(255, 245, 212));
        buttonGroup.add(rdbtnNewRadioButton_1_1);
        rdbtnNewRadioButton_1_1.setForeground(new Color(128, 0, 0));
        rdbtnNewRadioButton_1_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 25));
        rdbtnNewRadioButton_1_1.setBounds(1149, 422, 112, 42);
        getContentPane().add(rdbtnNewRadioButton_1_1);
        
        
        JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Offensif");
        rdbtnNewRadioButton_1.setBackground(new Color(255, 245, 212));
        buttonGroup.add(rdbtnNewRadioButton_1);
        rdbtnNewRadioButton_1.setForeground(new Color(128, 0, 0));
        rdbtnNewRadioButton_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 25));
        rdbtnNewRadioButton_1.setBounds(1048, 422, 99, 42);
        getContentPane().add(rdbtnNewRadioButton_1);
        
        
        JButton RPlusButton = new JButton("");
        RPlusButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		calculer(nombrepoint,rvalue,true);
        		NombrePointLable.setText(String.valueOf(nombrepoint.get()));
        		RValue.setText(String.valueOf(rvalue.get()));
        	}
        });
        RPlusButton.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/plus.png")));
        RPlusButton.setBounds(1206, 280, 30, 27);
        getContentPane().add(RPlusButton);
        
        JButton CMoinsButton = new JButton("");
        CMoinsButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		if(cvalue.get()>0) {
        			calculer(nombrepoint,cvalue,false);
        			NombrePointLable.setText(String.valueOf(nombrepoint.get()));
        			CValue.setText(String.valueOf(cvalue.get()));
        		}
    			else {
    				JOptionPane.showMessageDialog(null, "La valeur de la Constitution ne peut être inférieure à 0!", "Information", JOptionPane.INFORMATION_MESSAGE);
    			}
        	}
        });
        CMoinsButton.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/moins.png")));
        CMoinsButton.setBounds(1085, 333, 30, 27);
        getContentPane().add(CMoinsButton);
        
        JButton CPlusBuutton = new JButton("");
        CPlusBuutton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		calculer(nombrepoint,cvalue,true);
        		NombrePointLable.setText(String.valueOf(nombrepoint.get()));
        		CValue.setText(String.valueOf(cvalue.get()));
        	}
        });
        CPlusBuutton.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/plus.png")));
        CPlusBuutton.setBounds(1206, 333, 30, 27);
        getContentPane().add(CPlusBuutton);
        
        JButton IMoinsButton = new JButton("");
        IMoinsButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		if(ivalue.get()>0) {
        			calculer(nombrepoint,ivalue,false);
        			NombrePointLable.setText(String.valueOf(nombrepoint.get()));
        			IValue.setText(String.valueOf(ivalue.get()));
        		}
    			else {
    				JOptionPane.showMessageDialog(null, "La valeur de la Initiative ne peut être inférieure à 0!", "Information", JOptionPane.INFORMATION_MESSAGE);
    			}
        	}
        });
        IMoinsButton.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/moins.png")));
        IMoinsButton.setBounds(1085, 386, 30, 27);
        getContentPane().add(IMoinsButton);
        
        JButton IPlusButton = new JButton("");
        IPlusButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		calculer(nombrepoint,ivalue,true);
        		NombrePointLable.setText(String.valueOf(nombrepoint.get()));
        		IValue.setText(String.valueOf(ivalue.get()));
        	}
        });
        IPlusButton.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/plus.png")));
        IPlusButton.setBounds(1206, 386, 30, 27);
        getContentPane().add(IPlusButton);
        
        
        
        JLabel PointText = new JLabel("Point :");
        PointText.setForeground(new Color(128, 0, 0));
        PointText.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 35));
        PointText.setBounds(1113, 44, 112, 43);
        getContentPane().add(PointText);
        
        //NombrePointLable
        
        NombrePointLable.setText(String.valueOf(nombrepoint.get()));
        NombrePointLable.setForeground(new Color(128, 0, 0));
        NombrePointLable.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 35));
        NombrePointLable.setBounds(1221, 44, 57, 43);
        getContentPane().add(NombrePointLable);
        
        JLabel NiveauText = new JLabel("Niveau :");
        NiveauText.setForeground(new Color(128, 0, 0));
        NiveauText.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 40));
        NiveauText.setBounds(790, 473, 143, 40);
        getContentPane().add(NiveauText);
        
        JComboBox comboBox = new JComboBox();
        comboBox.setForeground(new Color(128, 0, 0));
        comboBox.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
        comboBox.setModel(new DefaultComboBoxModel(new String[] {"Soldat", "Soldat d’élite", "Maitre de Guerre"}));
        comboBox.setBackground(new Color(255, 245, 212));
        comboBox.setBounds(935, 477, 240, 35);
        getContentPane().add(comboBox);
        
        JLabel GuideText = new JLabel("Cliquez sur les images des soldats et attribuez-leur des attributs dans la boîte, vous disposez d'un total de 400 points.");
        GuideText.setForeground(SystemColor.info);
        GuideText.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 25));
        GuideText.setBounds(67, 652, 1180, 30);
        getContentPane().add(GuideText);
        
        JLabel AreaLable1 = new JLabel("La bibliothèque");
        AreaLable1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
        AreaLable1.setForeground(new Color(0, 0, 0));
        AreaLable1.setBounds(447, 548, 201, 42);
        getContentPane().add(AreaLable1);
        
        JLabel AreaLable2 = new JLabel("Le Bureau des Etudiants");
        AreaLable2.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
        AreaLable2.setForeground(new Color(0, 0, 0));
        AreaLable2.setBounds(436, 170, 304, 42);
        getContentPane().add(AreaLable2);
        
        JLabel AreaLable3 = new JLabel("Le Quartier Administratif");
        AreaLable3.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
        AreaLable3.setForeground(new Color(0, 0, 0));
        AreaLable3.setBounds(159, 232, 314, 42);
        getContentPane().add(AreaLable3);
        
        JLabel AreaLable4 = new JLabel("Les Halles industrielles");
        AreaLable4.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
        AreaLable4.setForeground(new Color(0, 0, 0));
        AreaLable4.setBounds(354, 393, 304, 42);
        getContentPane().add(AreaLable4);
        
        JLabel AreaLable5 = new JLabel("La Halle Sportive");
        AreaLable5.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
        AreaLable5.setForeground(new Color(0, 0, 0));
        AreaLable5.setBounds(172, 458, 201, 42);
        getContentPane().add(AreaLable5);
        
        //go_on
        Go_onButton.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/go_on.png")));
        Go_onButton.setBounds(616, 474, 157, 149);
        getContentPane().add(Go_onButton);
        Go_onButton.setVisible(false);
        
        //background
        JLabel BackgroundLabel1 = new JLabel("");
        BackgroundLabel1.setForeground(new Color(128, 0, 0));
        BackgroundLabel1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
        BackgroundLabel1.setIcon(new ImageIcon(PlayFrame.class.getResource("/imgs/play_background2.jpg")));
        BackgroundLabel1.setBounds(0, -13, 1400, 1000);
        getContentPane().add(BackgroundLabel1);
        
        
        
        
        
        
	}
}
