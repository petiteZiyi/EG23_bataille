package Bataille;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DetailFrame_green extends JFrame{

	private JFrame frame;
	// Création d'une nouvelle instance de MeleeFrameback
	MeleeFrameback meleeframeback = new MeleeFrameback();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DetailFrame_green window = new DetailFrame_green();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public DetailFrame_green() {
		meleeframeback.setVisible(false);
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Detail Frame");
        setBounds(100, 100, 1400, 1000);
        getContentPane().setLayout(null);
        
        // Création d'un bouton "ReturnButton" sans texte
        JButton ReturnButton = new JButton("");
        ReturnButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		setVisible(false); // Rend ce cadre invisible
        		meleeframeback.setVisible(true);// Rend le cadre 'meleeframeback' visible
        	}
        });
        // Définition de l'icône du bouton à partir des ressources
        ReturnButton.setIcon(new ImageIcon(DetailFrame_green.class.getResource("/imgs/return.png")));
        ReturnButton.setBounds(1259, 864, 142, 97);
        getContentPane().add(ReturnButton);
        ReturnButton.setBorderPainted(false);
        
        // Création d'une étiquette "BackgroundLabel" sans texte
        JLabel BackgroundLabel = new JLabel("");
        BackgroundLabel.setIcon(new ImageIcon(DetailFrame_green.class.getResource("/imgs/background5.png")));
        BackgroundLabel.setBounds(0, -15, 1400, 1000);
        getContentPane().add(BackgroundLabel);
        
        
	}
}
