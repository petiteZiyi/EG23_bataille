package Bataille;

import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;
import java.awt.Color;

public class MeleeFrame extends JFrame{

	private JFrame frame;
	DetailFrame_green detailframe_green = new DetailFrame_green();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MeleeFrame window = new MeleeFrame();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MeleeFrame() {
		detailframe_green.setVisible(false);
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Melée Frame");
        setBounds(100, 100, 1400, 1000);
        getContentPane().setLayout(null);
        
        
        //GreenButton
        JButton GreenButton = new JButton("");
        GreenButton.setIcon(new ImageIcon(MeleeFrame.class.getResource("/imgs/greenbutton.png")));
        GreenButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		detailframe_green.setVisible(true);
        		setVisible(false);
        	}
        });
        GreenButton.setBounds(463, 273, 165, 80);
        getContentPane().add(GreenButton);
        
        JLabel GuideText1 = new JLabel("La barre rouge représente les points de vies de l'ennemi.");
        GuideText1.setForeground(new Color(128, 0, 0));
        GuideText1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
        GuideText1.setBounds(42, 892, 742, 40);
        getContentPane().add(GuideText1);
        
        JLabel GuideText2 = new JLabel("La barre bleue représente vos propres points de vies.");
        GuideText2.setForeground(new Color(128, 0, 0));
        GuideText2.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 30));
        GuideText2.setBounds(730, 892, 742, 40);
        getContentPane().add(GuideText2);
        
        JLabel GuideText3 = new JLabel("Cliquez sur une barre pour connaître l'état exact de la bataille dans la zone.");
        GuideText3.setForeground(new Color(128, 0, 0));
        GuideText3.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 35));
        GuideText3.setBounds(277, 38, 1097, 40);
        getContentPane().add(GuideText3);
        
        //background
        JLabel BackgroundLabel1 = new JLabel("");
        BackgroundLabel1.setIcon(new ImageIcon(MeleeFrame.class.getResource("/imgs/background4.png")));
        BackgroundLabel1.setBounds(0, -14, 1400, 1000);
        getContentPane().add(BackgroundLabel1);
        
        
	}
}
