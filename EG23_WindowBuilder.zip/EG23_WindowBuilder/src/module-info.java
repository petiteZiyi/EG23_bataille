/**
 * 
 */
/**
 * 
 */
module EG23_WindowBuilder {
	requires java.desktop;
}